<?php
session_start();
//print_r($_SESSION);
?>


<html class="no-js wf-opensans-n3-active wf-opensans-i3-active wf-opensans-i4-active wf-opensans-n4-active wf-opensans-n6-active wf-opensans-n7-active wf-pacifico-n4-active wf-glegoo-n4-active wf-pathwaygothicone-n4-active wf-playfairdisplay-n4-active
wf-active" lang="pt-BR">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
    <title>Thais & Thiago</title>
    <meta content="Site mais bonito do Brasil! Crie seu site de casamento, lista de presentes, confirmação de presença e muito mais de maneira fácil e elegante." name="description">
    <meta title="">
    <meta content="200" property="og:image:width">
    <meta content="200" property="og:image:height">
    <meta content="https://files.casare.me/Fsmjaa.jpg" property="og:image">
    <meta content="https://www.casare.me/convites/2218219/ok" property="og:url">
    <meta content="Thiago &amp; Thais | Casare.me" property="og:title">
    <meta content="Começou a contagem regressiva, borboletas no estômago, uma mega ansiedade misturada com a Felicidade imensa de poder dividir com vocês todo esse Amor!&amp;nbsp;Apesar de 8 anos juntos e 6 dividindo a casa, as felicidades, tristezas e a vida e 3 filhas maravilhosas, nós sonhamos muito com essa oficialização! E pelo honra e glória de Deus determinamos que dessa ano que foi tão dificil não passaria!&amp;nbsp;&amp;nbsp;Nos conhecemos em janeiro de 2012 por um site de namoro chamado amores possivéis, conversamos por quase 2 meses, até que&amp;nbsp; o Rafa veio me conhecer, na época trabalhava no Escola da Familia e na escola Sussumo Hirata, e por isso nosso primeiro beijo foi no muro da escola perto da entrada e foi maravilhoso, e desde esse dia nossas vidas nunca mais foram separadas, claro que nesse percurssos enfrentamos muitos desafios, e que nos conhece de peto sabe que nossa história não é nem um conto de fadas, brigamos (muitooo rs), nos separamos, reatamos e nos reiventamos pra poder fazer dar certo! Nós nos amamos muito , muito mesmo e esse amor não deixou que nós nos separassemos, mas nem só de amor vive o&amp;nbsp; homem não é mesmo rs?Por isso em um determinado momento, quando já moravamos juntos, uma situação nos levou a uma decisão e desde esse dia , nps esforçmaos mais, nos respeitamos mais e decidimos que nó iamos fazerdar certo!&amp;nbsp;E Graças a Deus por isso, ele é maravilhoso e em primeiro lugar acima de nossas vidas ele sempre esteve cuidando de nós, poruque ele sabia, que nós seriamo felizes e nos conduziu ao momento exato que estamos hoje, muito felizes , com nossa data marcada e claro nossas 3 princesar lindas e maravilhosas que deixam nossa casa muito bagunçada rs, mais nos fazem transbordar de amor!Gostariamos de poder convidar todos nossos amigos mas devido ao momento, faremos um jantar com nossas familias e amigos qua já se tornaram familia no decorrer dos anos, ter vocês conosco, torcendo e acompanhando esse sonho é muito gratificanteEssa frase marcou muito nossa história e queremos compartilhar com vcs!&quot;No amor, não existem pessoas certas. Existem pessoas que lutam para dar certo&quot; e nós lutamos e cada dia que passa somas mais felizes e nos amamos ainda mais&amp;nbsp; 💖Aproveitem alguns minutos no nosso site, nele poderá encontrar endereço, horário, dicas especiais, lista de presentes e muito mais!!&amp;nbsp;&amp;nbsp;"
        property="og:description">
    <meta content="website" property="og:type">
    <meta content="https://www.casare.me" property="og:site_name">
    <meta content="pt_br" property="og:locale">
    <meta content="100000277447439" property="fb:admins">
    <meta content="170064306498870" property="fb:app_id">
    <meta content="authenticity_token" name="csrf-param">
    <meta content="aCfKFRWUvzibedFSm8cSnX8mTDnPQH/p8j1+A6YXlVg=" name="csrf-token">
    <link href="https://assets3.casare.me/assets/favicon-4f041989d8e4738a1597f2c65ce36439.png" rel="shortcut icon" type="image/x-icon">
    <link href="https://assets3.casare.me/assets/themes/classic/champagne_blue-005bc2d68155ea35237f6b2fd5abbf67.css" media="all" rel="stylesheet">
    <script type="text/javascript" async="" src="https://widget.intercom.io/widget/107d72b72ae8463dcd929cc9fd6a1dca27aab8f5"></script>
    <script src="https://connect.facebook.net/pt_BR/sdk.js?hash=ad3b5ba3cb2bdf97f3928b370871a1c9&amp;ua=modern_es6" async="" crossorigin="anonymous"></script>
    <script async="" src="//www.google-analytics.com/analytics.js"></script>
    <script type="text/javascript" id="www-widgetapi-script" src="https://s.ytimg.com/yts/jsbin/www-widgetapi-vfl3G6wqk/www-widgetapi.js" async=""></script>
    <script id="facebook-jssdk" src="//connect.facebook.net/pt_BR/sdk.js#xfbml=1&amp;version=v2.0"></script>
    <script type="text/javascript">
        window.is_downloader = false;
    </script>
    <script type="text/javascript">
        WebFontConfig = {
            google: {
                families: ["Open+Sans:300,300Italic,400italic,400,600,700:latin", "Pacifico::latin", "Glegoo::latin", "Pathway+Gothic+One::latin", "Playfair+Display::latin", "Pacifico"]
            }
        };
    </script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,300Italic,400italic,400,600,700%7CPacifico%7CGlegoo%7CPathway+Gothic+One%7CPlayfair+Display%7CPacifico&amp;subset=latin,latin,latin,latin,latin">
    <script type="text/javascript">
        ;
        (function(window, document, undefined) {
            var j = !0,
                k = null,
                l = !1;

            function p(a) {
                return function() {
                    return this[a]
                }
            }
            var aa = this;

            function q(a, b) {
                var c = a.split("."),
                    d = aa;
                !(c[0] in d) && d.execScript && d.execScript("var " + c[0]);
                for (var e; c.length && (e = c.shift());) !c.length && void 0 !== b ? d[e] = b : d = d[e] ? d[e] : d[e] = {}
            }

            function ba(a, b, c) {
                return a.call.apply(a.bind, arguments)
            }

            function ca(a, b, c) {
                if (!a) throw Error();
                if (2 < arguments.length) {
                    var d = Array.prototype.slice.call(arguments, 2);
                    return function() {
                        var c = Array.prototype.slice.call(arguments);
                        Array.prototype.unshift.apply(c, d);
                        return a.apply(b, c)
                    }
                }
                return function() {
                    return a.apply(b, arguments)
                }
            }

            function s(a, b, c) {
                s = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? ba : ca;
                return s.apply(k, arguments)
            }
            var da = Date.now || function() {
                return +new Date
            };

            function ea(a, b) {
                this.G = a;
                this.u = b || a;
                this.z = this.u.document
            }
            ea.prototype.createElement = function(a, b, c) {
                a = this.z.createElement(a);
                if (b)
                    for (var d in b) b.hasOwnProperty(d) && ("style" == d ? a.style.cssText = b[d] : a.setAttribute(d, b[d]));
                c && a.appendChild(this.z.createTextNode(c));
                return a
            };

            function fa(a, b, c) {
                a = a.z.getElementsByTagName(b)[0];
                a || (a = document.documentElement);
                a && a.lastChild && a.insertBefore(c, a.lastChild)
            }

            function t(a, b) {
                for (var c = a.className.split(/\s+/), d = 0, e = c.length; d < e; d++)
                    if (c[d] == b) return;
                c.push(b);
                a.className = c.join(" ").replace(/\s+/g, " ").replace(/^\s+|\s+$/, "")
            }

            function u(a, b) {
                for (var c = a.className.split(/\s+/), d = [], e = 0, f = c.length; e < f; e++) c[e] != b && d.push(c[e]);
                a.className = d.join(" ").replace(/\s+/g, " ").replace(/^\s+|\s+$/, "")
            }

            function ga(a, b) {
                for (var c = a.className.split(/\s+/), d = 0, e = c.length; d < e; d++)
                    if (c[d] == b) return j;
                return l
            }

            function v(a) {
                var b = a.u.location.protocol;
                "about:" == b && (b = a.G.location.protocol);
                return "https:" == b ? "https:" : "http:"
            }

            function w(a, b) {
                var c = a.createElement("link", {
                        rel: "stylesheet",
                        href: b
                    }),
                    d = l;
                c.onload = function() {
                    d || (d = j)
                };
                c.onerror = function() {
                    d || (d = j)
                };
                fa(a, "head", c)
            }

            function x(a, b, c, d) {
                var e = a.z.getElementsByTagName("head")[0];
                if (e) {
                    var f = a.createElement("script", {
                            src: b
                        }),
                        g = l;
                    f.onload = f.onreadystatechange = function() {
                        if (!g && (!this.readyState || "loaded" == this.readyState || "complete" == this.readyState)) g = j, c && c(k), f.onload = f.onreadystatechange = k, "HEAD" == f.parentNode.tagName && e.removeChild(f)
                    };
                    e.appendChild(f);
                    window.setTimeout(function() {
                        g || (g = j, c && c(Error("Script load timeout")))
                    }, d || 5E3);
                    return f
                }
                return k
            };

            function y(a, b, c) {
                this.w = a;
                this.S = b;
                this.za = c
            }
            q("webfont.BrowserInfo", y);
            y.prototype.pa = p("w");
            y.prototype.hasWebFontSupport = y.prototype.pa;
            y.prototype.qa = p("S");
            y.prototype.hasWebKitFallbackBug = y.prototype.qa;
            y.prototype.ra = p("za");
            y.prototype.hasWebKitMetricsBug = y.prototype.ra;

            function z(a, b, c, d) {
                this.e = a != k ? a : k;
                this.o = b != k ? b : k;
                this.aa = c != k ? c : k;
                this.f = d != k ? d : k
            }
            var ha = /^([0-9]+)(?:[\._-]([0-9]+))?(?:[\._-]([0-9]+))?(?:[\._+-]?(.*))?$/;
            z.prototype.toString = function() {
                return [this.e, this.o || "", this.aa || "", this.f || ""].join("")
            };

            function A(a) {
                a = ha.exec(a);
                var b = k,
                    c = k,
                    d = k,
                    e = k;
                a && (a[1] !== k && a[1] && (b = parseInt(a[1], 10)), a[2] !== k && a[2] && (c = parseInt(a[2], 10)), a[3] !== k && a[3] && (d = parseInt(a[3], 10)), a[4] !== k && a[4] && (e = /^[0-9]+$/.test(a[4]) ? parseInt(a[4], 10) : a[4]));
                return new z(b, c, d, e)
            };

            function B(a, b, c, d, e, f, g, h, m, n, r) {
                this.J = a;
                this.Fa = b;
                this.ya = c;
                this.fa = d;
                this.Da = e;
                this.ea = f;
                this.wa = g;
                this.Ea = h;
                this.va = m;
                this.da = n;
                this.k = r
            }
            q("webfont.UserAgent", B);
            B.prototype.getName = p("J");
            B.prototype.getName = B.prototype.getName;
            B.prototype.oa = p("ya");
            B.prototype.getVersion = B.prototype.oa;
            B.prototype.ka = p("fa");
            B.prototype.getEngine = B.prototype.ka;
            B.prototype.la = p("ea");
            B.prototype.getEngineVersion = B.prototype.la;
            B.prototype.ma = p("wa");
            B.prototype.getPlatform = B.prototype.ma;
            B.prototype.na = p("va");
            B.prototype.getPlatformVersion = B.prototype.na;
            B.prototype.ja = p("da");
            B.prototype.getDocumentMode = B.prototype.ja;
            B.prototype.ia = p("k");
            B.prototype.getBrowserInfo = B.prototype.ia;

            function C(a, b) {
                this.a = a;
                this.H = b
            }
            var ia = new B("Unknown", new z, "Unknown", "Unknown", new z, "Unknown", "Unknown", new z, "Unknown", void 0, new y(l, l, l));
            C.prototype.parse = function() {
                var a;
                if (-1 != this.a.indexOf("MSIE")) {
                    a = D(this);
                    var b = E(this),
                        c = A(b),
                        d = F(this.a, /MSIE ([\d\w\.]+)/, 1),
                        e = A(d);
                    a = new B("MSIE", e, d, "MSIE", e, d, a, c, b, G(this.H), new y("Windows" == a && 6 <= e.e || "Windows Phone" == a && 8 <= c.e, l, l))
                } else if (-1 != this.a.indexOf("Opera")) a: {
                    a = "Unknown";
                    var b = F(this.a, /Presto\/([\d\w\.]+)/, 1),
                        c = A(b),
                        d = E(this),
                        e = A(d),
                        f = G(this.H);c.e !== k ? a = "Presto" : (-1 != this.a.indexOf("Gecko") && (a = "Gecko"), b = F(this.a, /rv:([^\)]+)/, 1), c = A(b));
                    if (-1 != this.a.indexOf("Opera Mini/")) {
                        var g =
                            F(this.a, /Opera Mini\/([\d\.]+)/, 1),
                            h = A(g);
                        a = new B("OperaMini", h, g, a, c, b, D(this), e, d, f, new y(l, l, l))
                    } else {
                        if (-1 != this.a.indexOf("Version/") && (g = F(this.a, /Version\/([\d\.]+)/, 1), h = A(g), h.e !== k)) {
                            a = new B("Opera", h, g, a, c, b, D(this), e, d, f, new y(10 <= h.e, l, l));
                            break a
                        }
                        g = F(this.a, /Opera[\/ ]([\d\.]+)/, 1);
                        h = A(g);
                        a = h.e !== k ? new B("Opera", h, g, a, c, b, D(this), e, d, f, new y(10 <= h.e, l, l)) : new B("Opera", new z, "Unknown", a, c, b, D(this), e, d, f, new y(l, l, l))
                    }
                }
                else /OPR\/[\d.]+/.test(this.a) ? a = ja(this) : /AppleWeb(K|k)it/.test(this.a) ?
                    a = ja(this) : -1 != this.a.indexOf("Gecko") ? (a = "Unknown", b = new z, c = "Unknown", d = E(this), e = A(d), f = l, -1 != this.a.indexOf("Firefox") ? (a = "Firefox", c = F(this.a, /Firefox\/([\d\w\.]+)/, 1), b = A(c), f = 3 <= b.e && 5 <= b.o) : -1 != this.a.indexOf("Mozilla") && (a = "Mozilla"), g = F(this.a, /rv:([^\)]+)/, 1), h = A(g), f || (f = 1 < h.e || 1 == h.e && 9 < h.o || 1 == h.e && 9 == h.o && 2 <= h.aa || g.match(/1\.9\.1b[123]/) != k || g.match(/1\.9\.1\.[\d\.]+/) != k), a = new B(a, b, c, "Gecko", h, g, D(this), e, d, G(this.H), new y(f, l, l))) : a = ia;
                return a
            };

            function D(a) {
                var b = F(a.a, /(iPod|iPad|iPhone|Android|Windows Phone|BB\d{2}|BlackBerry)/, 1);
                if ("" != b) return /BB\d{2}/.test(b) && (b = "BlackBerry"), b;
                a = F(a.a, /(Linux|Mac_PowerPC|Macintosh|Windows|CrOS)/, 1);
                return "" != a ? ("Mac_PowerPC" == a && (a = "Macintosh"), a) : "Unknown"
            }

            function E(a) {
                var b = F(a.a, /(OS X|Windows NT|Android) ([^;)]+)/, 2);
                if (b || (b = F(a.a, /Windows Phone( OS)? ([^;)]+)/, 2)) || (b = F(a.a, /(iPhone )?OS ([\d_]+)/, 2))) return b;
                if (b = F(a.a, /(?:Linux|CrOS) ([^;)]+)/, 1))
                    for (var b = b.split(/\s/), c = 0; c < b.length; c += 1)
                        if (/^[\d\._]+$/.test(b[c])) return b[c];
                return (a = F(a.a, /(BB\d{2}|BlackBerry).*?Version\/([^\s]*)/, 2)) ? a : "Unknown"
            }

            function ja(a) {
                var b = D(a),
                    c = E(a),
                    d = A(c),
                    e = F(a.a, /AppleWeb(?:K|k)it\/([\d\.\+]+)/, 1),
                    f = A(e),
                    g = "Unknown",
                    h = new z,
                    m = "Unknown",
                    n = l;
                /OPR\/[\d.]+/.test(a.a) ? g = "Opera" : -1 != a.a.indexOf("Chrome") || -1 != a.a.indexOf("CrMo") || -1 != a.a.indexOf("CriOS") ? g = "Chrome" : /Silk\/\d/.test(a.a) ? g = "Silk" : "BlackBerry" == b || "Android" == b ? g = "BuiltinBrowser" : -1 != a.a.indexOf("PhantomJS") ? g = "PhantomJS" : -1 != a.a.indexOf("Safari") ? g = "Safari" : -1 != a.a.indexOf("AdobeAIR") && (g = "AdobeAIR");
                "BuiltinBrowser" == g ? m = "Unknown" : "Silk" == g ? m = F(a.a,
                    /Silk\/([\d\._]+)/, 1) : "Chrome" == g ? m = F(a.a, /(Chrome|CrMo|CriOS)\/([\d\.]+)/, 2) : -1 != a.a.indexOf("Version/") ? m = F(a.a, /Version\/([\d\.\w]+)/, 1) : "AdobeAIR" == g ? m = F(a.a, /AdobeAIR\/([\d\.]+)/, 1) : "Opera" == g ? m = F(a.a, /OPR\/([\d.]+)/, 1) : "PhantomJS" == g && (m = F(a.a, /PhantomJS\/([\d.]+)/, 1));
                h = A(m);
                n = "AdobeAIR" == g ? 2 < h.e || 2 == h.e && 5 <= h.o : "BlackBerry" == b ? 10 <= d.e : "Android" == b ? 2 < d.e || 2 == d.e && 1 < d.o : 526 <= f.e || 525 <= f.e && 13 <= f.o;
                return new B(g, h, m, "AppleWebKit", f, e, b, d, c, G(a.H), new y(n, 536 > f.e || 536 == f.e && 11 > f.o, "iPhone" ==
                    b || "iPad" == b || "iPod" == b || "Macintosh" == b))
            }

            function F(a, b, c) {
                return (a = a.match(b)) && a[c] ? a[c] : ""
            }

            function G(a) {
                if (a.documentMode) return a.documentMode
            };

            function ka(a) {
                this.ua = a || "-"
            }
            ka.prototype.f = function(a) {
                for (var b = [], c = 0; c < arguments.length; c++) b.push(arguments[c].replace(/[\W_]+/g, "").toLowerCase());
                return b.join(this.ua)
            };

            function H(a, b) {
                this.J = a;
                this.T = 4;
                this.K = "n";
                var c = (b || "n4").match(/^([nio])([1-9])$/i);
                c && (this.K = c[1], this.T = parseInt(c[2], 10))
            }
            H.prototype.getName = p("J");

            function I(a) {
                return a.K + a.T
            }

            function la(a) {
                var b = 4,
                    c = "n",
                    d = k;
                a && ((d = a.match(/(normal|oblique|italic)/i)) && d[1] && (c = d[1].substr(0, 1).toLowerCase()), (d = a.match(/([1-9]00|normal|bold)/i)) && d[1] && (/bold/i.test(d[1]) ? b = 7 : /[1-9]00/.test(d[1]) && (b = parseInt(d[1].substr(0, 1), 10))));
                return c + b
            };

            function ma(a, b, c) {
                this.c = a;
                this.h = b;
                this.M = c;
                this.j = "wf";
                this.g = new ka("-")
            }

            function na(a) {
                t(a.h, a.g.f(a.j, "loading"));
                J(a, "loading")
            }

            function K(a) {
                u(a.h, a.g.f(a.j, "loading"));
                ga(a.h, a.g.f(a.j, "active")) || t(a.h, a.g.f(a.j, "inactive"));
                J(a, "inactive")
            }

            function J(a, b, c) {
                if (a.M[b])
                    if (c) a.M[b](c.getName(), I(c));
                    else a.M[b]()
            };

            function L(a, b) {
                this.c = a;
                this.C = b;
                this.s = this.c.createElement("span", {
                    "aria-hidden": "true"
                }, this.C)
            }

            function M(a, b) {
                var c;
                c = [];
                for (var d = b.J.split(/,\s*/), e = 0; e < d.length; e++) {
                    var f = d[e].replace(/['"]/g, ""); - 1 == f.indexOf(" ") ? c.push(f) : c.push("'" + f + "'")
                }
                c = c.join(",");
                d = "normal";
                e = b.T + "00";
                "o" === b.K ? d = "oblique" : "i" === b.K && (d = "italic");
                a.s.style.cssText = "position:absolute;top:-999px;left:-999px;font-size:300px;width:auto;height:auto;line-height:normal;margin:0;padding:0;font-variant:normal;white-space:nowrap;font-family:" + c + ";" + ("font-style:" + d + ";font-weight:" + e + ";")
            }

            function N(a) {
                fa(a.c, "body", a.s)
            }
            L.prototype.remove = function() {
                var a = this.s;
                a.parentNode && a.parentNode.removeChild(a)
            };

            function oa(a, b, c, d, e, f, g, h) {
                this.U = a;
                this.sa = b;
                this.c = c;
                this.q = d;
                this.C = h || "BESbswy";
                this.k = e;
                this.F = {};
                this.R = f || 5E3;
                this.Y = g || k;
                this.B = this.A = k;
                a = new L(this.c, this.C);
                N(a);
                for (var m in O) O.hasOwnProperty(m) && (M(a, new H(O[m], I(this.q))), this.F[O[m]] = a.s.offsetWidth);
                a.remove()
            }
            var O = {
                Ca: "serif",
                Ba: "sans-serif",
                Aa: "monospace"
            };
            oa.prototype.start = function() {
                this.A = new L(this.c, this.C);
                N(this.A);
                this.B = new L(this.c, this.C);
                N(this.B);
                this.xa = da();
                M(this.A, new H(this.q.getName() + ",serif", I(this.q)));
                M(this.B, new H(this.q.getName() + ",sans-serif", I(this.q)));
                qa(this)
            };

            function ra(a, b, c) {
                for (var d in O)
                    if (O.hasOwnProperty(d) && b === a.F[O[d]] && c === a.F[O[d]]) return j;
                return l
            }

            function qa(a) {
                var b = a.A.s.offsetWidth,
                    c = a.B.s.offsetWidth;
                b === a.F.serif && c === a.F["sans-serif"] || a.k.S && ra(a, b, c) ? da() - a.xa >= a.R ? a.k.S && ra(a, b, c) && (a.Y === k || a.Y.hasOwnProperty(a.q.getName())) ? P(a, a.U) : P(a, a.sa) : setTimeout(s(function() {
                    qa(this)
                }, a), 25) : P(a, a.U)
            }

            function P(a, b) {
                a.A.remove();
                a.B.remove();
                b(a.q)
            };

            function R(a, b, c, d) {
                this.c = b;
                this.t = c;
                this.N = 0;
                this.ba = this.X = l;
                this.R = d;
                this.k = a.k
            }

            function sa(a, b, c, d, e) {
                if (0 === b.length && e) K(a.t);
                else {
                    a.N += b.length;
                    e && (a.X = e);
                    for (e = 0; e < b.length; e++) {
                        var f = b[e],
                            g = c[f.getName()],
                            h = a.t,
                            m = f;
                        t(h.h, h.g.f(h.j, m.getName(), I(m).toString(), "loading"));
                        J(h, "fontloading", m);
                        (new oa(s(a.ga, a), s(a.ha, a), a.c, f, a.k, a.R, d, g)).start()
                    }
                }
            }
            R.prototype.ga = function(a) {
                var b = this.t;
                u(b.h, b.g.f(b.j, a.getName(), I(a).toString(), "loading"));
                u(b.h, b.g.f(b.j, a.getName(), I(a).toString(), "inactive"));
                t(b.h, b.g.f(b.j, a.getName(), I(a).toString(), "active"));
                J(b, "fontactive", a);
                this.ba = j;
                ta(this)
            };
            R.prototype.ha = function(a) {
                var b = this.t;
                u(b.h, b.g.f(b.j, a.getName(), I(a).toString(), "loading"));
                ga(b.h, b.g.f(b.j, a.getName(), I(a).toString(), "active")) || t(b.h, b.g.f(b.j, a.getName(), I(a).toString(), "inactive"));
                J(b, "fontinactive", a);
                ta(this)
            };

            function ta(a) {
                0 == --a.N && a.X && (a.ba ? (a = a.t, u(a.h, a.g.f(a.j, "loading")), u(a.h, a.g.f(a.j, "inactive")), t(a.h, a.g.f(a.j, "active")), J(a, "active")) : K(a.t))
            };

            function S(a, b, c) {
                this.G = a;
                this.V = b;
                this.a = c;
                this.O = this.P = 0
            }

            function T(a, b) {
                U.V.Z[a] = b
            }
            S.prototype.load = function(a) {
                var b = a.context || this.G;
                this.c = new ea(this.G, b);
                b = new ma(this.c, b.document.documentElement, a);
                if (this.a.k.w) {
                    var c = this.V,
                        d = this.c,
                        e = [],
                        f;
                    for (f in a)
                        if (a.hasOwnProperty(f)) {
                            var g = c.Z[f];
                            g && e.push(g(a[f], d))
                        }
                    a = a.timeout;
                    this.O = this.P = e.length;
                    a = new R(this.a, this.c, b, a);
                    f = 0;
                    for (c = e.length; f < c; f++) d = e[f], d.v(this.a, s(this.ta, this, d, b, a))
                } else K(b)
            };
            S.prototype.ta = function(a, b, c, d) {
                var e = this;
                d ? a.load(function(a, d, h) {
                    var m = 0 == --e.P;
                    m && na(b);
                    setTimeout(function() {
                        sa(c, a, d || {}, h || k, m)
                    }, 0)
                }) : (a = 0 == --this.P, this.O--, a && (0 == this.O ? K(b) : na(b)), sa(c, [], {}, k, a))
            };
            var ua = window,
                va = (new C(navigator.userAgent, document)).parse(),
                U = ua.WebFont = new S(window, new function() {
                    this.Z = {}
                }, va);
            U.load = U.load;

            function V(a, b) {
                this.c = a;
                this.d = b
            }
            V.prototype.load = function(a) {
                var b, c, d = this.d.urls || [],
                    e = this.d.families || [];
                b = 0;
                for (c = d.length; b < c; b++) w(this.c, d[b]);
                d = [];
                b = 0;
                for (c = e.length; b < c; b++) {
                    var f = e[b].split(":");
                    if (f[1])
                        for (var g = f[1].split(","), h = 0; h < g.length; h += 1) d.push(new H(f[0], g[h]));
                    else d.push(new H(f[0]))
                }
                a(d)
            };
            V.prototype.v = function(a, b) {
                return b(a.k.w)
            };
            T("custom", function(a, b) {
                return new V(b, a)
            });

            function W(a, b) {
                this.c = a;
                this.d = b;
                this.m = []
            }
            W.prototype.D = function(a) {
                return v(this.c) + (this.d.api || "//f.fontdeck.com/s/css/js/") + (this.c.u.location.hostname || this.c.G.location.hostname) + "/" + a + ".js"
            };
            W.prototype.v = function(a, b) {
                var c = this.d.id,
                    d = this.c.u,
                    e = this;
                c ? (d.__webfontfontdeckmodule__ || (d.__webfontfontdeckmodule__ = {}), d.__webfontfontdeckmodule__[c] = function(a, c) {
                    for (var d = 0, m = c.fonts.length; d < m; ++d) {
                        var n = c.fonts[d];
                        e.m.push(new H(n.name, la("font-weight:" + n.weight + ";font-style:" + n.style)))
                    }
                    b(a)
                }, x(this.c, this.D(c), function(a) {
                    a && b(l)
                })) : b(l)
            };
            W.prototype.load = function(a) {
                a(this.m)
            };
            T("fontdeck", function(a, b) {
                return new W(b, a)
            });

            function wa(a, b, c) {
                this.L = a ? a : b + xa;
                this.p = [];
                this.Q = [];
                this.ca = c || ""
            }
            var xa = "//fonts.googleapis.com/css";
            wa.prototype.f = function() {
                if (0 == this.p.length) throw Error("No fonts to load !");
                if (-1 != this.L.indexOf("kit=")) return this.L;
                for (var a = this.p.length, b = [], c = 0; c < a; c++) b.push(this.p[c].replace(/ /g, "+"));
                a = this.L + "?family=" + b.join("%7C");
                0 < this.Q.length && (a += "&subset=" + this.Q.join(","));
                0 < this.ca.length && (a += "&text=" + encodeURIComponent(this.ca));
                return a
            };

            function ya(a) {
                this.p = a;
                this.$ = [];
                this.I = {}
            }
            var za = {
                    latin: "BESbswy",
                    cyrillic: "&#1081;&#1103;&#1046;",
                    greek: "&#945;&#946;&#931;",
                    khmer: "&#x1780;&#x1781;&#x1782;",
                    Hanuman: "&#x1780;&#x1781;&#x1782;"
                },
                Aa = {
                    thin: "1",
                    extralight: "2",
                    "extra-light": "2",
                    ultralight: "2",
                    "ultra-light": "2",
                    light: "3",
                    regular: "4",
                    book: "4",
                    medium: "5",
                    "semi-bold": "6",
                    semibold: "6",
                    "demi-bold": "6",
                    demibold: "6",
                    bold: "7",
                    "extra-bold": "8",
                    extrabold: "8",
                    "ultra-bold": "8",
                    ultrabold: "8",
                    black: "9",
                    heavy: "9",
                    l: "3",
                    r: "4",
                    b: "7"
                },
                Ba = {
                    i: "i",
                    italic: "i",
                    n: "n",
                    normal: "n"
                },
                Ca = RegExp("^(thin|(?:(?:extra|ultra)-?)?light|regular|book|medium|(?:(?:semi|demi|extra|ultra)-?)?bold|black|heavy|l|r|b|[1-9]00)?(n|i|normal|italic)?$");
            ya.prototype.parse = function() {
                for (var a = this.p.length, b = 0; b < a; b++) {
                    var c = this.p[b].split(":"),
                        d = c[0].replace(/\+/g, " "),
                        e = ["n4"];
                    if (2 <= c.length) {
                        var f;
                        var g = c[1];
                        f = [];
                        if (g)
                            for (var g = g.split(","), h = g.length, m = 0; m < h; m++) {
                                var n;
                                n = g[m];
                                if (n.match(/^[\w]+$/)) {
                                    n = Ca.exec(n.toLowerCase());
                                    var r = void 0;
                                    if (n == k) r = "";
                                    else {
                                        r = void 0;
                                        r = n[1];
                                        if (r == k || "" == r) r = "4";
                                        else var pa = Aa[r],
                                            r = pa ? pa : isNaN(r) ? "4" : r.substr(0, 1);
                                        r = [n[2] == k || "" == n[2] ? "n" : Ba[n[2]], r].join("")
                                    }
                                    n = r
                                } else n = "";
                                n && f.push(n)
                            }
                        0 < f.length && (e = f);
                        3 == c.length &&
                            (c = c[2], f = [], c = !c ? f : c.split(","), 0 < c.length && (c = za[c[0]]) && (this.I[d] = c))
                    }
                    this.I[d] || (c = za[d]) && (this.I[d] = c);
                    for (c = 0; c < e.length; c += 1) this.$.push(new H(d, e[c]))
                }
            };

            function X(a, b, c) {
                this.a = a;
                this.c = b;
                this.d = c
            }
            var Da = {
                Arimo: j,
                Cousine: j,
                Tinos: j
            };
            X.prototype.v = function(a, b) {
                b(a.k.w)
            };
            X.prototype.load = function(a) {
                var b = this.c;
                if ("MSIE" == this.a.getName() && this.d.blocking != j) {
                    var c = s(this.W, this, a),
                        d = function() {
                            b.z.body ? c() : setTimeout(d, 0)
                        };
                    d()
                } else this.W(a)
            };
            X.prototype.W = function(a) {
                for (var b = this.c, c = new wa(this.d.api, v(b), this.d.text), d = this.d.families, e = d.length, f = 0; f < e; f++) {
                    var g = d[f].split(":");
                    3 == g.length && c.Q.push(g.pop());
                    var h = "";
                    2 == g.length && "" != g[1] && (h = ":");
                    c.p.push(g.join(h))
                }
                d = new ya(d);
                d.parse();
                w(b, c.f());
                a(d.$, d.I, Da)
            };
            T("google", function(a, b) {
                var c = (new C(navigator.userAgent, document)).parse();
                return new X(c, b, a)
            });

            function Y(a, b) {
                this.c = a;
                this.d = b
            }
            var Ea = {
                regular: "n4",
                bold: "n7",
                italic: "i4",
                bolditalic: "i7",
                r: "n4",
                b: "n7",
                i: "i4",
                bi: "i7"
            };
            Y.prototype.v = function(a, b) {
                return b(a.k.w)
            };
            Y.prototype.load = function(a) {
                w(this.c, v(this.c) + "//webfonts.fontslive.com/css/" + this.d.key + ".css");
                for (var b = this.d.families, c = [], d = 0, e = b.length; d < e; d++) c.push.apply(c, Fa(b[d]));
                a(c)
            };

            function Fa(a) {
                var b = a.split(":");
                a = b[0];
                if (b[1]) {
                    for (var c = b[1].split(","), b = [], d = 0, e = c.length; d < e; d++) {
                        var f = c[d];
                        if (f) {
                            var g = Ea[f];
                            b.push(g ? g : f)
                        }
                    }
                    c = [];
                    for (d = 0; d < b.length; d += 1) c.push(new H(a, b[d]));
                    return c
                }
                return [new H(a)]
            }
            T("ascender", function(a, b) {
                return new Y(b, a)
            });

            function Z(a, b, c) {
                this.a = a;
                this.c = b;
                this.d = c;
                this.m = []
            }
            Z.prototype.v = function(a, b) {
                var c = this,
                    d = c.d.projectId,
                    e = c.d.version;
                if (d) {
                    var f = c.c.u;
                    x(this.c, c.D(d, e), function(e) {
                        if (e) b(l);
                        else {
                            if (f["__mti_fntLst" + d] && (e = f["__mti_fntLst" + d]()))
                                for (var h = 0; h < e.length; h++) c.m.push(new H(e[h].fontfamily));
                            b(a.k.w)
                        }
                    }).id = "__MonotypeAPIScript__" + d
                } else b(l)
            };
            Z.prototype.D = function(a, b) {
                var c = v(this.c),
                    d = (this.d.api || "fast.fonts.com/jsapi").replace(/^.*http(s?):(\/\/)?/, "");
                return c + "//" + d + "/" + a + ".js" + (b ? "?v=" + b : "")
            };
            Z.prototype.load = function(a) {
                a(this.m)
            };
            T("monotype", function(a, b) {
                var c = (new C(navigator.userAgent, document)).parse();
                return new Z(c, b, a)
            });

            function $(a, b) {
                this.c = a;
                this.d = b;
                this.m = []
            }
            $.prototype.D = function(a) {
                var b = v(this.c);
                return (this.d.api || b + "//use.typekit.net") + "/" + a + ".js"
            };
            $.prototype.v = function(a, b) {
                var c = this.d.id,
                    d = this.d,
                    e = this.c.u,
                    f = this;
                c ? (e.__webfonttypekitmodule__ || (e.__webfonttypekitmodule__ = {}), e.__webfonttypekitmodule__[c] = function(c) {
                    c(a, d, function(a, c, d) {
                        for (var e = 0; e < c.length; e += 1) {
                            var g = d[c[e]];
                            if (g)
                                for (var Q = 0; Q < g.length; Q += 1) f.m.push(new H(c[e], g[Q]));
                            else f.m.push(new H(c[e]))
                        }
                        b(a)
                    })
                }, x(this.c, this.D(c), function(a) {
                    a && b(l)
                }, 2E3)) : b(l)
            };
            $.prototype.load = function(a) {
                a(this.m)
            };
            T("typekit", function(a, b) {
                return new $(b, a)
            });
            window.WebFontConfig && U.load(window.WebFontConfig);
        })(this, document);
    </script>
    <!--[if lt IE 9]><script src="https://assets3.casare.me/assets/html5shiv/dist/html5shiv-printshiv-dfc8905645d1f14810033582212f70c2.js"></script><![endif]-->
    <style type="text/css" data-fbcssmodules="css:fb.css.basecss:fb.css.dialog css:fb.css.iframewidget">
        .fb_hidden {
            position: absolute;
            top: -10000px;
            z-index: 10001
        }

        .fb_reposition {
            overflow: hidden;
            position: relative
        }

        .fb_invisible {
            display: none
        }

        .fb_reset {
            background: none;
            border: 0;
            border-spacing: 0;
            color: #000;
            cursor: auto;
            direction: ltr;
            font-family: "lucida grande", tahoma, verdana, arial, sans-serif;
            font-size: 11px;
            font-style: normal;
            font-variant: normal;
            font-weight: normal;
            letter-spacing: normal;
            line-height: 1;
            margin: 0;
            overflow: visible;
            padding: 0;
            text-align: left;
            text-decoration: none;
            text-indent: 0;
            text-shadow: none;
            text-transform: none;
            visibility: visible;
            white-space: normal;
            word-spacing: normal
        }

        .fb_reset>div {
            overflow: hidden
        }

        @keyframes fb_transform {
            from {
                opacity: 0;
                transform: scale(.95)
            }
            to {
                opacity: 1;
                transform: scale(1)
            }
        }

        .fb_animate {
            animation: fb_transform .3s forwards
        }

        .fb_dialog {
            background: rgba(82, 82, 82, .7);
            position: absolute;
            top: -10000px;
            z-index: 10001
        }

        .fb_dialog_advanced {
            border-radius: 8px;
            padding: 10px
        }

        .fb_dialog_content {
            background: #fff;
            color: #373737
        }

        .fb_dialog_close_icon {
            background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;
            cursor: pointer;
            display: block;
            height: 15px;
            position: absolute;
            right: 18px;
            top: 17px;
            width: 15px
        }

        .fb_dialog_mobile .fb_dialog_close_icon {
            left: 5px;
            right: auto;
            top: 5px
        }

        .fb_dialog_padding {
            background-color: transparent;
            position: absolute;
            width: 1px;
            z-index: -1
        }

        .fb_dialog_close_icon:hover {
            background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent
        }

        .fb_dialog_close_icon:active {
            background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent
        }

        .fb_dialog_iframe {
            line-height: 0
        }

        .fb_dialog_content .dialog_title {
            background: #6d84b4;
            border: 1px solid #365899;
            color: #fff;
            font-size: 14px;
            font-weight: bold;
            margin: 0
        }

        .fb_dialog_content .dialog_title>span {
            background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;
            float: left;
            padding: 5px 0 7px 26px
        }

        body.fb_hidden {
            height: 100%;
            left: 0;
            margin: 0;
            overflow: visible;
            position: absolute;
            top: -10000px;
            transform: none;
            width: 100%
        }

        .fb_dialog.fb_dialog_mobile.loading {
            background: url(https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;
            min-height: 100%;
            min-width: 100%;
            overflow: hidden;
            position: absolute;
            top: 0;
            z-index: 10001
        }

        .fb_dialog.fb_dialog_mobile.loading.centered {
            background: none;
            height: auto;
            min-height: initial;
            min-width: initial;
            width: auto
        }

        .fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner {
            width: 100%
        }

        .fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content {
            background: none
        }

        .loading.centered #fb_dialog_loader_close {
            clear: both;
            color: #fff;
            display: block;
            font-size: 18px;
            padding-top: 20px
        }

        #fb-root #fb_dialog_ipad_overlay {
            background: rgba(0, 0, 0, .4);
            bottom: 0;
            left: 0;
            min-height: 100%;
            position: absolute;
            right: 0;
            top: 0;
            width: 100%;
            z-index: 10000
        }

        #fb-root #fb_dialog_ipad_overlay.hidden {
            display: none
        }

        .fb_dialog.fb_dialog_mobile.loading iframe {
            visibility: hidden
        }

        .fb_dialog_mobile .fb_dialog_iframe {
            position: sticky;
            top: 0
        }

        .fb_dialog_content .dialog_header {
            background: linear-gradient(from(#738aba), to(#2c4987));
            border-bottom: 1px solid;
            border-color: #043b87;
            box-shadow: white 0 1px 1px -1px inset;
            color: #fff;
            font: bold 14px Helvetica, sans-serif;
            text-overflow: ellipsis;
            text-shadow: rgba(0, 30, 84, .296875) 0 -1px 0;
            vertical-align: middle;
            white-space: nowrap
        }

        .fb_dialog_content .dialog_header table {
            height: 43px;
            width: 100%
        }

        .fb_dialog_content .dialog_header td.header_left {
            font-size: 12px;
            padding-left: 5px;
            vertical-align: middle;
            width: 60px
        }

        .fb_dialog_content .dialog_header td.header_right {
            font-size: 12px;
            padding-right: 5px;
            vertical-align: middle;
            width: 60px
        }

        .fb_dialog_content .touchable_button {
            background: linear-gradient(from(#4267B2), to(#2a4887));
            background-clip: padding-box;
            border: 1px solid #29487d;
            border-radius: 3px;
            display: inline-block;
            line-height: 18px;
            margin-top: 3px;
            max-width: 85px;
            padding: 4px 12px;
            position: relative
        }

        .fb_dialog_content .dialog_header .touchable_button input {
            background: none;
            border: none;
            color: #fff;
            font: bold 12px Helvetica, sans-serif;
            margin: 2px -12px;
            padding: 2px 6px 3px 6px;
            text-shadow: rgba(0, 30, 84, .296875) 0 -1px 0
        }

        .fb_dialog_content .dialog_header .header_center {
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            line-height: 18px;
            text-align: center;
            vertical-align: middle
        }

        .fb_dialog_content .dialog_content {
            background: url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;
            border: 1px solid #4a4a4a;
            border-bottom: 0;
            border-top: 0;
            height: 150px
        }

        .fb_dialog_content .dialog_footer {
            background: #f5f6f7;
            border: 1px solid #4a4a4a;
            border-top-color: #ccc;
            height: 40px
        }

        #fb_dialog_loader_close {
            float: left
        }

        .fb_dialog.fb_dialog_mobile .fb_dialog_close_icon {
            visibility: hidden
        }

        #fb_dialog_loader_spinner {
            animation: rotateSpinner 1.2s linear infinite;
            background-color: transparent;
            background-image: url(https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);
            background-position: 50% 50%;
            background-repeat: no-repeat;
            height: 24px;
            width: 24px
        }

        @keyframes rotateSpinner {
            0% {
                transform: rotate(0deg)
            }
            100% {
                transform: rotate(360deg)
            }
        }

        .fb_iframe_widget {
            display: inline-block;
            position: relative
        }

        .fb_iframe_widget span {
            display: inline-block;
            position: relative;
            text-align: justify
        }

        .fb_iframe_widget iframe {
            position: absolute
        }

        .fb_iframe_widget_fluid_desktop,
        .fb_iframe_widget_fluid_desktop span,
        .fb_iframe_widget_fluid_desktop iframe {
            max-width: 100%
        }

        .fb_iframe_widget_fluid_desktop iframe {
            min-width: 220px;
            position: relative
        }

        .fb_iframe_widget_lift {
            z-index: 1
        }

        .fb_iframe_widget_fluid {
            display: inline
        }

        .fb_iframe_widget_fluid span {
            width: 100%
        }
    </style>
</head>

<body data-offset="100" data-spy="scroll" data-target=".navbar-default" cz-shortcut-listen="true">
    <div id="fb-root" class=" fb_reset">
        <div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
            <div></div>
        </div>
    </div>
    <div class="container" style="color:#555;">
        <div class="row rsvp-confirm">
            <div class="col-xs-8 col-xs-offset-2 text-center"><br><img alt="Icon ok" class="text-center" height="80" src="https://assets3.casare.me/assets/wedding/icon-ok-17573f7fa31129a612cc9071f98b22ec.png" width="80">
                <p></p>
                <h3 class="text-center pathway-font uppercase"><?php
                    if($_SESSION['name'])
                        if($_SESSION['status'] == 'não sei')
                            $msg = "Obrigado, {$_SESSION['name']}, aguardamos sua confirmação.";
                        elseif($_SESSION['status'] == 'confirmou') 
                            $msg = "Obrigado, {$_SESSION['name']}, sua presença foi confirmada.";  
                        else
                            $msg = "É uma pena, {$_SESSION['name']}, sua presença seria muito gratificante.";  
                    echo $msg;
                ?>
                </h3>
            </div>
        </div>
        <div class="row rsvp-confirm">
            <div class="col-xs-12 text-center"><br><a class="btn btn-success btn-orange btn-lg pathway-font uppercase" href="https://www.thaiserafa.life">veja nosso Site de Casamento</a></div>
        </div>
    </div>
    <!--[if (gte IE 6)&(lte IE 8)]><script src="https://assets3.casare.me/assets/nwmatcher/src/nwmatcher-ab0ba7c8f49769825b426eba60f892c5.js"></script><script src="https://assets3.casare.me/assets/selectivizr/selectivizr-01397808a76a7260b0689aca9bdc42ab.js"></script><![endif]-->
    <script type="text/javascript">
        window.I18n = window.I18n || {};
        window.I18n.defaultLocale = "pt-BR";
        window.I18n.locale = "pt-BR";
        window.I18n.fallbacks = true;
    </script>
    <script src="https://assets3.casare.me/assets/themes/classic-5726c2246be10f3fe5f712a54e35da1e.js"></script>
    <style type="text/css" media="screen" id="show-more-stile-rules">
        .show-more {
            margin-top: -65px;
            padding-top: 65px
        }
    </style>
    <!-- Google Tag Manager -->
    <noscript>
<iframe height='0' src='//www.googletagmanager.com/ns.html?id=GTM-T9W54P' style='display:none;visibility:hidden' width='0'></iframe>
</noscript>
    <script>
        (function(i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function() {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-42524851-3', 'auto');
        ga('send', 'pageview');
    </script>
    <script id="IntercomSettingsScriptTag">
        window.intercomSettings = {
            "email": "thah.adm@gmail.com",
            "name": "Thais P Santos",
            "created_at": 1597450523,
            "user_id": 111703,
            "casamento_id": 104581,
            "slug": "thaisandrafa",
            "whatsapp": "+55(11)98767-5280",
            "big_day_at": 1607806800,
            "login_pelo_FB": false,
            "auto_login_ticket": "coMIQvIlZfixJCTOL9Git5DUqt7MXrJUSO1U9Okkpzw9bqozwlAYmz3YlhKARv1L",
            "tema": "Classic",
            "sub_tema": "Champagne \u0026 Blue",
            "reviewed": false,
            "comprou_download": false,
            "valor_compra": 0.0,
            "dominio": "thaiserafa.life",
            "site_url": "https://www.thaiserafa.life",
            "campaign_id": 5,
            "gift_count": 0,
            "plan": "Plano Especial Lista",
            "period": 9,
            "start_at": 1597450866,
            "end_at": 1621047599,
            "festa": true,
            "cerimonia": false,
            "cha_de_panela": false,
            "cerimonia_e_festa": false,
            "cha_bar": false,
            "cha_de_langerie": false,
            "festa_de_noivado": false,
            "luau": false,
            "recepcao": false,
            "presentes_virtuais": true,
            "despedida_de_solteiro": false,
            "despedida_de_solteira": false,
            "casamento_e_recepcao": false,
            "casamento_civil": false,
            "cerimonia_civil": false,
            "cafe_da_manha": false,
            "happy_hour": false,
            "cha": false,
            "festa_at": 1628554524,
            "cerimonia_at": null,
            "cha_de_panela_at": null,
            "cerimonia_e_festa_at": null,
            "cha_bar_at": null,
            "cha_de_cozinha_at": null,
            "cha_de_lingerie_at": null,
            "festa_de_noivado_at": null,
            "luau_at": null,
            "recepcao_at": null,
            "despedida_de_solteiro_at": null,
            "despedida_de_solteira_at": null,
            "casamento_e_recepcao_at": null,
            "casamento_civil_at": null,
            "cerimonia_civil_at": null,
            "cafe_da_manha_at": null,
            "happy_hour_at": null,
            "cupom_desconto_20_20": "A00026EBEFED98B",
            "cupom_desconto_20_20_usado_em": null,
            "cupom_plano_paypal_88": "A00035D6AB385FC",
            "cupom_plano_paypal_88_usado_em": null,
            "cupom_download_20_20": "A000415573BD564",
            "cupom_download_20_20_usado_em": null,
            "cupom_paypal_100": "A000195FD835D18",
            "cupom_paypal_100_usado_em": null,
            "user_hash": "402576b12992e750f0430e4f7dade8c4650843757b296cfe44af03c1903f3139",
            "app_id": "107d72b72ae8463dcd929cc9fd6a1dca27aab8f5",
            "widget": {
                "activator": "#IntercomDefaultWidget"
            }
        };
        (function() {
            var w = window;
            var ic = w.Intercom;
            if (typeof ic === "function") {
                ic('reattach_activator');
                ic('update', intercomSettings);
            } else {
                var d = document;
                var i = function() {
                    i.c(arguments)
                };
                i.q = [];
                i.c = function(args) {
                    i.q.push(args)
                };
                w.Intercom = i;

                function l() {
                    var s = d.createElement('script');
                    s.type = 'text/javascript';
                    s.async = true;
                    s.src = 'https://widget.intercom.io/widget/107d72b72ae8463dcd929cc9fd6a1dca27aab8f5';
                    var x = d.getElementsByTagName('script')[0];
                    x.parentNode.insertBefore(s, x);
                }
                if (w.attachEvent) {
                    w.attachEvent('onload', l);
                } else {
                    w.addEventListener('load', l, false);
                }
            };
        })()
    </script>
    <iframe id="intercom-frame" style="position: absolute !important; opacity: 0 !important; width: 1px !important; height: 1px !important; top: 0 !important; left: 0 !important; border: none !important; display: block !important; z-index: -1 !important; pointer-events: none;"
        aria-hidden="true" tabindex="-1" title="Intercom"></iframe>
    <div class="intercom-lightweight-app" aria-live="polite">
        <div class="intercom-lightweight-app-launcher intercom-launcher" role="button" tabindex="0" aria-label="Open Intercom Messenger">
            <div class="intercom-lightweight-app-launcher-icon intercom-lightweight-app-launcher-icon-open"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 32"><path d="M28 32s-4.714-1.855-8.527-3.34H3.437C1.54 28.66 0 27.026 0 25.013V3.644C0 1.633 1.54 0 3.437 0h21.125c1.898 0 3.437 1.632 3.437 3.645v18.404H28V32zm-4.139-11.982a.88.88 0 00-1.292-.105c-.03.026-3.015 2.681-8.57 2.681-5.486 0-8.517-2.636-8.571-2.684a.88.88 0 00-1.29.107 1.01 1.01 0 00-.219.708.992.992 0 00.318.664c.142.128 3.537 3.15 9.762 3.15 6.226 0 9.621-3.022 9.763-3.15a.992.992 0 00.317-.664 1.01 1.01 0 00-.218-.707z"></path></svg></div>
            <div
                class="intercom-lightweight-app-launcher-icon intercom-lightweight-app-launcher-icon-minimize"><svg viewBox="0 0 16 14" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M.116 4.884l1.768-1.768L8 9.232l6.116-6.116 1.768 1.768L8 12.768.116 4.884z"></path></svg></div>
    </div>
    <style id="intercom-lightweight-app-style" type="text/css">
        @keyframes intercom-lightweight-app-launcher {
            from {
                opacity: 0;
                transform: scale(0.5);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        @keyframes intercom-lightweight-app-gradient {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes intercom-lightweight-app-messenger {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .intercom-lightweight-app {
            position: fixed;
            z-index: 2147483001;
            width: 0;
            height: 0;
            font-family: intercom-font, "Helvetica Neue", "Apple Color Emoji", Helvetica, Arial, sans-serif;
        }

        .intercom-lightweight-app-gradient {
            position: fixed;
            z-index: 2147483002;
            width: 500px;
            height: 500px;
            bottom: 0;
            right: 0;
            pointer-events: none;
            background: radial-gradient( ellipse at bottom right, rgba(29, 39, 54, 0.16) 0%, rgba(29, 39, 54, 0) 72%);
            animation: intercom-lightweight-app-gradient 200ms ease-out;
        }

        .intercom-lightweight-app-launcher {
            position: fixed;
            z-index: 2147483003;
            bottom: 20px;
            right: 20px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: #2f86c4;
            cursor: pointer;
            box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.06), 0 2px 32px 0 rgba(0, 0, 0, 0.16);
            animation: intercom-lightweight-app-launcher 250ms ease;
        }

        .intercom-lightweight-app-launcher:focus {
            outline: none;
        }

        .intercom-lightweight-app-launcher-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            position: absolute;
            top: 0;
            left: 0;
            width: 60px;
            height: 60px;
            transition: transform 100ms linear, opacity 80ms linear;
        }

        .intercom-lightweight-app-launcher-icon-open {
            opacity: 1;
            transform: rotate(0deg) scale(1);
        }

        .intercom-lightweight-app-launcher-icon-open svg {
            width: 28px;
            height: 32px;
        }

        .intercom-lightweight-app-launcher-icon-open svg path {
            fill: rgb(255, 255, 255);
        }

        .intercom-lightweight-app-launcher-icon-self-serve {
            opacity: 1;
            transform: rotate(0deg) scale(1);
        }

        .intercom-lightweight-app-launcher-icon-self-serve svg {
            height: 56px;
        }

        .intercom-lightweight-app-launcher-icon-self-serve svg path {
            fill: rgb(255, 255, 255);
        }

        .intercom-lightweight-app-launcher-custom-icon-open {
            max-height: 36px;
            max-width: 36px;
            opacity: 1;
            transform: rotate(0deg) scale(1);
        }

        .intercom-lightweight-app-launcher-icon-minimize {
            opacity: 0;
            transform: rotate(-60deg) scale(0);
        }

        .intercom-lightweight-app-launcher-icon-minimize svg {
            width: 16px;
        }

        .intercom-lightweight-app-launcher-icon-minimize svg path {
            fill: rgb(255, 255, 255);
        }

        .intercom-lightweight-app-messenger {
            position: fixed;
            z-index: 2147483003;
            overflow: hidden;
            background-color: white;
            animation: intercom-lightweight-app-messenger 250ms ease-out;
            width: 376px;
            height: calc(100% - 120px);
            max-height: 704px;
            min-height: 250px;
            right: 20px;
            bottom: 100px;
            box-shadow: 0 5px 40px rgba(0, 0, 0, 0.16);
            border-radius: 8px;
        }

        .intercom-lightweight-app-messenger-header {
            height: 75px;
            background: linear-gradient( 135deg, rgb(109, 148, 176) 0%, rgb(64, 96, 119) 100%);
        }

        @media print {
            .intercom-lightweight-app {
                display: none;
            }
        }
    </style>
    </div>
</body>

</html>