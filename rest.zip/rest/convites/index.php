<?php 

/*header("Access-Control-Allow-Headers: *"); 
header("Access-Control-Allow-Origin: *"); */

if(isset($_POST['body']) && !empty($_POST['body'])){
	$data = $_POST['body'];
}else{
	$data = file_get_contents("php://input");
}
$file = "convites.json";
file_put_contents($file, $data );

print_r( file_get_contents( $file ) ); 

//print_r($data);